<?php
include('../attachment/session.php');


$sql0 = "select * from student_admission_info where student_class='4TH' and student_medium='Hindi'";
$result0=mysqli_query($conn73,$sql0);
while($row0=mysqli_fetch_assoc($result0)){
$s_no = $row0['s_no'];
$student_name11 =$row0['student_name'];

$sql01 = "update student_admission_info set school_roll_no='$student_name11' where s_no='$s_no'";
if(mysqli_query($conn73,$sql01)){
	
//$student_id_generate=275;
//$student_roll_no=1900275;
$sql = "select * from student_admission_info_new where school_roll_no='$student_name11'";
$result=mysqli_query($conn73,$sql);
while($row=mysqli_fetch_assoc($result)){
$company_name = $row['company_name'];
$student_registration_fee =$row['student_registration_fee'];
$student_bus_fee_category =$row['student_bus_fee_category'];
$student_bus_fee_category_code =$row['student_bus_fee_category_code'];
$house_name =$row['house_name'];
//$student_id_generate =$row['student_id_generate'];
$student_name =$row['student_name'];
$student_father_name =$row['student_father_name'];
$student_mother_name =$row['student_mother_name'];
$student_class =$row['student_class'];
$student_class_stream =$row['student_class_stream'];
$student_class_group =$row['student_class_group'];
$student_class_section ='A';
//$student_class_section =$row['student_class_section'];
//$student_roll_no =$row['student_roll_no'];
$student_password =$row['student_password'];
//$school_roll_no =$row['school_roll_no'];
$student_date_of_birth =$row['student_date_of_birth'];
$student_date_of_birth_month =$row['student_date_of_birth_month'];
$student_date_of_birth_date =$row['student_date_of_birth_date'];
$student_gender =$row['student_gender'];
$student_handicapped =$row['student_handicapped'];
$student_cwsn =$row['student_cwsn'];
$student_cwsn_description =$row['student_cwsn_description'];
$student_caste =$row['student_caste'];
$student_religion =$row['student_religion'];
$student_category =$row['student_category'];
$student_rf_id_number =$row['student_rf_id_number'];
$student_adhar_number =$row['student_adhar_number'];
$student_father_adhar_card_number =$row['student_father_adhar_card_number'];
$student_sssmid_number =$row['student_sssmid_number'];
$student_family_id =$row['student_family_id'];
$student_child_id =$row['student_child_id'];
$student_father_bank_name =$row['student_father_bank_name'];
$student_father_bank_account_number =$row['student_father_bank_account_number'];
$student_father_bank_ifsc_code =$row['student_father_bank_ifsc_code'];
$student_bank_name =$row['student_bank_name'];
$student_account_number =$row['student_account_number'];
$student_bank_ifsc_code =$row['student_bank_ifsc_code'];
$student_admission_type =$row['student_admission_type'];
$stuent_old_or_new =$row['stuent_old_or_new'];
$student_medium =$row['student_medium'];
$student_date_of_admission =$row['student_date_of_admission'];
$student_date_of_birth_in_word =$row['student_date_of_birth_in_word'];
$student_previous_class =$row['student_previous_class'];
$student_previous_school_name =$row['student_previous_school_name'];
$student_previous_class_marks =$row['student_previous_class_marks'];
$student_admission_scheme =$row['student_admission_scheme'];
$student_sibling_name_1 =$row['student_sibling_name_1'];
$student_sibling_unique_id_1 =$row['student_sibling_unique_id_1'];
$student_sibling_name_2 =$row['student_sibling_name_2'];
$student_sibling_unique_id_2 =$row['student_sibling_unique_id_2'];
$student_admission_number =$row['student_admission_number'];
$student_scholar_number =$row['student_scholar_number'];
$student_father_contact_number =$row['student_father_contact_number'];
$student_father_contact_number2 =$row['student_father_contact_number2'];
$student_father_email_id =$row['student_father_email_id'];
$student_mother_contact_number =$row['student_mother_contact_number'];
$student_mother_email_id =$row['student_mother_email_id'];
$student_father_occupation =$row['student_father_occupation'];
$student_mother_occupation =$row['student_mother_occupation'];
$student_guardian_name =$row['student_guardian_name'];
$student_guardian_relation =$row['student_guardian_relation'];
$student_guardian_contact_number =$row['student_guardian_contact_number'];
$student_guardian_email_id =$row['student_guardian_email_id'];
$student_guardian_occupation =$row['student_guardian_occupation'];
$student_contact_number =$row['student_contact_number'];
$student_email_id =$row['student_email_id'];
$student_adress =$row['student_adress'];
$student_city =$row['student_city'];
$student_district =$row['student_district'];
$student_state =$row['student_state'];
$student_pincode =$row['student_pincode'];
$student_landmark =$row['student_landmark'];
$student_block =$row['student_block'];
$student_address_permanent =$row['student_address_permanent'];
$student_state_permanent =$row['student_state_permanent'];
$student_district_permanent =$row['student_district_permanent'];
$student_block_permanent =$row['student_block_permanent'];
$student_city_permanent =$row['student_city_permanent'];
$student_pincode_permanent =$row['student_pincode_permanent'];
$student_last_passed_marksheet =$row['student_last_passed_marksheet'];
$student_tc =$row['student_tc'];
$student_income_certificate =$row['student_income_certificate'];
$student_caste_certificate =$row['student_caste_certificate'];
$student_dob_certificate =$row['student_dob_certificate'];
$student_photo =$row['student_photo'];
$student_parents_photo =$row['student_parents_photo'];
$student_guardian_photo =$row['student_guardian_photo'];
$student_facility =$row['student_facility'];
$student_bus =$row['student_bus'];
$student_hostel =$row['student_hostel'];
$student_library =$row['student_library'];
$student_status =$row['student_status'];
$registration_final =$row['registration_final'];
$update_status =$row['update_status'];
$update_change =$row['update_change'];
$student_admission_remark =$row['student_admission_remark'];
$student_sms_contact_number =$row['student_sms_contact_number'];
$student_web_sms =$row['student_web_sms'];
$student_walk_through =$row['student_walk_through'];
$student_walk_with =$row['student_walk_with'];
$class_change_by =$row['class_change_by'];
$last_updated_date =$row['last_updated_date'];
$blank_field_1 =$row['blank_field_1'];
$blank_field_2 =$row['blank_field_2'];
$blank_field_3 =$row['blank_field_3'];
$blank_field_4 =$row['blank_field_4'];
$blank_field_5 =$row['blank_field_5'];
$student_remark_1 =$row['student_remark_1'];
$student_remark_2 =$row['student_remark_2'];
$student_remark_3 =$row['student_remark_3'];
$student_remark_4 =$row['student_remark_4'];
$student_bus_no =$row['student_bus_no'];
$student_hostel_name =$row['student_hostel_name'];
$student_hostel_room_no =$row['student_hostel_room_no'];
$student_bus_route =$row['student_bus_route'];
$session_value =$row['session_value'];
$student_identity_category =$row['student_identity_category'];
$attendance_sync =$row['attendance_sync'];
$medium =$row['medium'];
$school =$row['school'];
$board =$row['board'];
$shift =$row['shift'];
$filter1 =$row['filter1'];
$filter2 =$row['filter2'];
$filter3 =$row['filter3'];
$student_fee_category =$row['student_fee_category'];
$student_fee_category_code =$row['student_fee_category_code'];
$pickup_point =$row['pickup_point'];
$drop_point =$row['drop_point'];
$trip =$row['trip'];
$hostel_bed_no =$row['hostel_bed_no'];

$donation =$row['donation'];
$donar_name =$row['donar_name'];
//$student_parents_photo_blob =$row['student_parents_photo_blob'];
//$student_photo_blob =$row['student_photo_blob'];
//$student_guardian_photo_blob =$row['student_guardian_photo_blob'];
$student_registration_number =$row['student_registration_number'];
$student_enrollment_number =$row['student_enrollment_number'];
$sql1="update student_admission_info set company_name='$company_name', student_registration_fee='$student_registration_fee', student_bus_fee_category='$student_bus_fee_category', student_bus_fee_category_code='$student_bus_fee_category_code', house_name='$house_name', student_name='$student_name', student_father_name='$student_father_name', student_mother_name='$student_mother_name', student_class='$student_class', student_class_stream='$student_class_stream', student_class_group='$student_class_group', student_class_section='$student_class_section', student_password='$student_password', student_date_of_birth='$student_date_of_birth', student_date_of_birth_month='$student_date_of_birth_month', student_date_of_birth_date='$student_date_of_birth_date', student_gender='$student_gender', student_handicapped='$student_handicapped', student_cwsn='$student_cwsn', student_cwsn_description='$student_cwsn_description', student_caste='$student_caste', student_religion='$student_religion', student_category='$student_category', student_rf_id_number='$student_rf_id_number', student_adhar_number='$student_adhar_number', student_father_adhar_card_number='$student_father_adhar_card_number', student_sssmid_number='$student_sssmid_number', student_family_id='$student_family_id', student_child_id='$student_child_id', student_father_bank_name='$student_father_bank_name', student_father_bank_account_number='$student_father_bank_account_number', student_father_bank_ifsc_code='$student_father_bank_ifsc_code', student_bank_name='$student_bank_name', student_account_number='$student_account_number', student_bank_ifsc_code='$student_bank_ifsc_code', student_admission_type='$student_admission_type', stuent_old_or_new='$stuent_old_or_new', student_medium='$student_medium', student_date_of_admission='$student_date_of_admission', student_date_of_birth_in_word='$student_date_of_birth_in_word', student_previous_class='$student_previous_class', student_previous_school_name='$student_previous_school_name', student_previous_class_marks='$student_previous_class_marks', student_admission_scheme='$student_admission_scheme', student_sibling_name_1='$student_sibling_name_1', student_sibling_unique_id_1='$student_sibling_unique_id_1', student_sibling_name_2='$student_sibling_name_2', student_sibling_unique_id_2='$student_sibling_unique_id_2', student_admission_number='$student_admission_number', student_scholar_number='$student_scholar_number', student_father_contact_number='$student_father_contact_number', student_father_contact_number2='$student_father_contact_number2', student_father_email_id='$student_father_email_id', student_mother_contact_number='$student_mother_contact_number', student_mother_email_id='$student_mother_email_id', student_father_occupation='$student_father_occupation', student_mother_occupation='$student_mother_occupation', student_guardian_name='$student_guardian_name', student_guardian_relation='$student_guardian_relation', student_guardian_contact_number='$student_guardian_contact_number', student_guardian_email_id='$student_guardian_email_id', student_guardian_occupation='$student_guardian_occupation', student_contact_number='$student_contact_number', student_email_id='$student_email_id', student_adress='$student_adress', student_city='$student_city', student_district='$student_district', student_state='$student_state', student_pincode='$student_pincode', student_landmark='$student_landmark', student_block='$student_block', student_address_permanent='$student_address_permanent', student_state_permanent='$student_state_permanent', student_district_permanent='$student_district_permanent', student_block_permanent='$student_block_permanent', student_city_permanent='$student_city_permanent', student_pincode_permanent='$student_pincode_permanent', student_last_passed_marksheet='$student_last_passed_marksheet', student_tc='$student_tc', student_income_certificate='$student_income_certificate', student_caste_certificate='$student_caste_certificate', student_dob_certificate='$student_dob_certificate', student_photo='$student_photo', student_parents_photo='$student_parents_photo', student_guardian_photo='$student_guardian_photo', student_facility='$student_facility', student_bus='$student_bus', student_hostel='$student_hostel', student_library='$student_library', student_status='$student_status', registration_final='$registration_final', update_status='$update_status', update_change='$update_change', student_admission_remark='$student_admission_remark', student_sms_contact_number='$student_sms_contact_number', student_web_sms='$student_web_sms', student_walk_through='$student_walk_through', student_walk_with='$student_walk_with', class_change_by='$class_change_by', last_updated_date='$last_updated_date', blank_field_1='$blank_field_1', blank_field_2='$blank_field_2', blank_field_3='$blank_field_3', blank_field_4='$blank_field_4', blank_field_5='$blank_field_5', student_remark_1='$student_remark_1', student_remark_2='$student_remark_2', student_remark_3='$student_remark_3', student_remark_4='$student_remark_4', student_bus_no='$student_bus_no', student_hostel_name='$student_hostel_name', student_hostel_room_no='$student_hostel_room_no', student_bus_route='$student_bus_route', session_value='$session_value', student_identity_category='$student_identity_category', attendance_sync='$attendance_sync', medium='$medium', school='$school', board='$board', shift='$shift', filter1='$filter1', filter2='$filter2', filter3='$filter3', student_fee_category='$student_fee_category', student_fee_category_code='$student_fee_category_code', pickup_point='$pickup_point', drop_point='$drop_point', trip='$trip', hostel_bed_no='$hostel_bed_no', donation='$donation', donar_name='$donar_name', student_registration_number='$student_registration_number', student_enrollment_number='$student_enrollment_number' where school_roll_no='$student_name11'";
if(mysqli_query($conn73,$sql1)){
//$student_id_generate++;
//$student_roll_no++;
echo "Data imported";
} else {
echo "Data not imported ";
}
}
	
}

}
?>