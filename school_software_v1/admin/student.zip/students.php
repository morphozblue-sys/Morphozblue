<?php include("../attachment/session.php"); ?>
    <section class="content-header">
      <h1>
        Student Management
        <small>Control Panel</small>
      </h1>
      <ol class="breadcrumb">
	 <li><a href="javascript:get_content('index_content')"><i class="fa fa-dashboard"></i> Home</a></li>
	  <li class="active">Student</li>
      </ol>
    </section>

    <section class="content">
            <div <div class="box <?php echo $box_head_color; ?>" >
				<div class="box-header with-border">
				  
				  <h3 class="box-title" style="color:teal;"><i class="fa fa-book"></i>&nbsp;&nbsp;&nbsp;<b>Main Panel</b></h3>
				</div>
				<div class="box-body">
	<?php  if(!isset($_SESSION['sub_panel_student_registration'])){ ?>	
	
	    <a href="javascript:get_content('student/student_registration')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#E32636;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;"><?php echo $language['Registration']; ?></h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
             <a href="javascript:get_content('student/student_registration')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>		
		
	 <?php } if(!isset($_SESSION['sub_panel_student_registration_list'])){ ?>
 		<a href="javascript:get_content('student/student_registration_list')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#3B7A57;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;"><?php echo $language['Registration List']; ?></h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>

            <a href="javascript:get_content('student/student_registration_list')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
	<?php } if(!isset($_SESSION['sub_panel_student_admission_list'])){ ?>
 		<a href="javascript:get_content('student/student_admission_list')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#9F2B68;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;"><?php echo $language['Admission List']; ?></h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
     
            <a href="javascript:get_content('student/student_admission_list')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
		
   	<?php } if(!isset($_SESSION['sub_panel_student_action'])){ ?>
 	    <a href="javascript:get_content('student/student_action')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#34B334;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;"><?php echo $language['One Click']; ?></h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
   
            <a href="javascript:get_content('student/student_action')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>        			 
	 			 
	<?php } if(!isset($_SESSION['student_sub_panel_profile_update'])){ ?>
 		 <a href="javascript:get_content('student/student_profile_update')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#003366;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Profile Update</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/student_profile_update')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
		
		
	<?php } if(!isset($_SESSION['student_sub_panel_mapping_data_update'])){ ?>
 		 <a href="javascript:get_content('student/student_mapping_data_update')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#FF7373;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Mapping Data Update</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/student_mapping_data_update')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
			<?php } if(!isset($_SESSION['student_sub_panel_photo_update'])){ ?>
 		 <a href="javascript:get_content('student/student_photo_update')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#daa520;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Photo Update</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/student_photo_update')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
			<?php } if(!isset($_SESSION['student_sub_panel_sms_contact_update'])){ if(false){ ?>
				<a href="javascript:get_content('student/student_sms_contact_update')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#D67BBC;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">SMS Contact Update</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/student_sms_contact_update')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
			<?php }} if(!isset($_SESSION['student_sub_panel_web_sms'])){ if(false){ ?>
		<a href="javascript:get_content('student/student_sms_notification_update')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#585858;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Web SMS</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/student_sms_notification_update')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
     			 
			<?php } } if(!isset($_SESSION['sub_panel_student_roll_no'])){ ?>
 	    <a href="javascript:get_content('student/student_roll_no')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:	#FF7E00;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;"><?php echo $language['Roll No Generate']; ?></h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/student_roll_no')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
  	<?php  } if(!isset($_SESSION['sub_panel_student_donation'])){ ?>
  	
 		 <a href="javascript:get_content('student/donation_student_add')">
        <div class="col-md-3 col-md-6" style="display:none;">
          <div class="small-box" style="background-color:#8040FF;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Donation Student</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/donation_student_add')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
		 <?php  } if(!isset($_SESSION['sub_panel_student_id_card'])){ ?>
 		 <a href="javascript:get_content('student/student_id_card')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#804040;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Student <?php echo $language['Id Generate']; ?></h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/student_id_card')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
		<?php  } if(!isset($_SESSION['student_sub_panel_guardian_id_card'])){ ?>			
	  <a href="javascript:get_content('student/guardian_student_id_card')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#FF6848;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Guardian Id Generate</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/guardian_student_id_card')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>	
	   <?php  } if(!isset($_SESSION['student_sub_panel_father_id_card'])){ ?>
		<a href="javascript:get_content('student/father_student_id_card')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#12C8fA;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Father Id Generate</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/father_student_id_card')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
		<?php  } if(!isset($_SESSION['student_sub_panel_mother_id_card'])){ ?>
		<a href="javascript:get_content('student/mother_student_id_card')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#02C87A;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;">Mother Id Generate</h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/mother_student_id_card')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
 		
			
			<?php }  if(!isset($_SESSION['sub_panel_health_zone'])){ ?>
 				<a href="javascript:get_content('student/health_zone')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#551B8C;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;"><?php echo $language['Medical Fitness']; ?></h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/health_zone')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
	 			 	<?php } if(!isset($_SESSION['sub_panel_physical_fitness'])){ ?>
 				<a href="javascript:get_content('student/physical_fitness')">
        <div class="col-md-3 col-md-6">
          <div class="small-box" style="background-color:#72A0C1;">
            <div class="inner"><br>
               <h3 style="font-size:20px;margin-left:5px;color:#fff;"><?php echo $language['Physical Fitness']; ?></h3>
				<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
            </div>
            <a href="javascript:get_content('student/physical_fitness')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		</a>
		        
	 			 	<?php } ?>
		
      </div>
      </div>
       <div <div class="box <?php echo $box_head_color; ?>" >
				<div class="box-header with-border">
				  
				  <h3 class="box-title" style="color:teal;"><i class="fa fa-exclamation-circle"></i>&nbsp;&nbsp;&nbsp;<b>Reports</b></h3>
				</div>
				<div class="box-body">
				    
				    <?php  if(!isset($_SESSION['student_sub_panel_student_strength_castwise'])){ ?>
						<a href="javascript:get_content('student/report_student_strength_castewise')">
					<div class="col-md-3 col-md-6">
						<div class="small-box" style="background-color:#ffd700;">
							<div class="inner"><br>
							 <h3 style="font-size:20px;margin-left:5px;color:#fff;">Student Strength Caste Wise</h3>
							<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
						</div>
	
							<a href="javascript:get_content('student/report_student_strength_castewise')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
						</div>
					</div>
					</a>
					
					
					<?php } if(!isset($_SESSION['student_sub_panel_student_strength_religionwise'])){ ?>
					<a href="javascript:get_content('student/report_student_strength_religionwise')">
					<div class="col-md-3 col-md-6">
						<div class="small-box" style="background-color:#4617a0;">
							<div class="inner"><br>
							 <h3 style="font-size:20px;margin-left:5px;color:#fff;">Student Strength Religion Wise</h3>
							<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
						</div>
				            <a href="javascript:get_content('student/report_student_strength_religionwise')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
						</div>
					</div>
					</a>
			        <?php } ?>
			        
			       
			        
			        
			        <a href="javascript:get_content('student/student_registration_report')">
					<div class="col-md-3 col-md-6">
						<div class="small-box" style="background-color:#898281;">
							<div class="inner"><br>
							 <h3 style="font-size:20px;margin-left:5px;color:#fff;">Student Registration</h3>
							<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
						</div>
				            <a href="javascript:get_content('student/student_registration_report')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
						</div>
					</div>
					</a> 
					<a href="javascript:get_content('student/report_student_strength_agewise')">
					<div class="col-md-3 col-md-6">
						<div class="small-box" style="background-color:#800000;">
							<div class="inner"><br>
							 <h3 style="font-size:20px;margin-left:5px;color:#fff;">Student Agewise Strength-1</h3>
							<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
						</div>
				            <a href="javascript:get_content('student/report_student_strength_agewise')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
						</div>
					</div>
					</a>
						<a href="javascript:get_content('student/report_student_strength_agewise_total')">
					<div class="col-md-3 col-md-6">
						<div class="small-box" style="background-color:#008000;">
							<div class="inner"><br>
							 <h3 style="font-size:20px;margin-left:5px;color:#fff;">Student Agewise Strength-2</h3>
							<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
						</div>
				            <a href="javascript:get_content('student/report_student_strength_agewise_total')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
						</div>
					</div>
					</a>
						<a href="javascript:get_content('student/report_student_strength_agewise_vertical')">
					<div class="col-md-3 col-md-6">
						<div class="small-box" style="background-color:#000080;">
							<div class="inner"><br>
							 <h3 style="font-size:20px;margin-left:5px;color:#fff;">Student Agewise Strength=3</h3>
							<p style="margin-left:10px;color:#fff;"><?php echo $language['Enter']; ?></p>
						</div>
				            <a href="javascript:get_content('student/report_student_strength_agewise_vertical')" class="small-box-footer"><?php echo $language['More info']; ?> <i class="fa fa-arrow-circle-right"></i></a>
						</div>
					</div>
					</a>
                 </div>
                 </div>
                 
                 
    
                 
    </section>

