<?php include("../attachment/session.php"); ?>
    <section class="content-header">
      <h1>
        <?php echo $language['Student Management']; ?>
        <small><?php echo $language['Control Panel']; ?></small>
      </h1>
      <ol class="breadcrumb">
	 <li><a href="javascript:get_content('index_content')"><i class="fa fa-dashboard"></i> Home</a></li>
	  <li><a href="javascript:get_content('student/students')"><i class="fa fa-graduation-cap"></i> <?php echo $language['Student']; ?></a></li>
	  <li class="active">Admission Form List</li>
      </ol>
    </section>
    
<script>
	function valid(s_no){
	var myval=confirm("Are you sure want to delete this record !!!!");
	if(myval==true){
	delete_record(s_no);
	}else{
	return false;
	}
	}
	
	function delete_record(s_no){
	$.ajax({
	type: "POST",
	url: access_link+"student/online_admission_form_delete.php?s_no="+s_no+"",
	cache: false,
	success: function(detail){
	var res=detail.split("|?|");
	if(res[1]=='success'){
	   alert_new('Successfully Deleted',"red");
	   get_content('student/online_admission_form_list');
	}else if(res[1]=='session_not_set'){
                alert_new('Session Expire !!!',"red");
            }else{
	// alert_new(detail); 
	}
	}
	});
	}
	
	function for_status(s_no,value){
	$.ajax({
	type: "POST",
	url: access_link+"student/online_admission_form_enable_disable.php?s_no="+s_no+"&value="+value+"",
	cache: false,
	success: function(detail){
	var res=detail.split("|?|");
	if(res[1]=='success'){
	   alert_new('Successfully Completed',"green");
	   get_content('student/online_admission_form_list');
	}else if(res[1]=='session_not_set'){
                alert_new('Session Expire !!!',"red");
            }else{
	// alert_new(detail); 
	}
	}
	});
	}
	</script>

	<!---******************************************************************************************************-->
 <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
    <div class="box box-primary my_border_top">
            <div class="box-header with-border ">
            <h3 class="box-title pull-right"><a href="javascript:get_content('student/online_admission_form_list_download')"><button type="button" class="btn btn-success" >Download</button></a></h3>
            </div>
 <div class="box-body ">
	<div class="col-md-12">
                <!-- /.box -->

                <div <div class="box <?php echo $box_head_color; ?>" >>
                <div class="box-header with-border">
                </div>
			
		<div class="box-body table-responsive" id="search_list">
				  <table id="example1" class="table table-bordered table-striped">
						<thead >
							             <tr>
				  <th>S.No</th>
				  <th>Roll No</th>
				  <th>Selection Marks</th>
				  <th>Student Name</th>
				  <th>Admission Class</th>
				  <th>Student Contact No.</th>
				  <th>Student Category</th>
				  <th>Student DOB</th>
				  <th>Student Gender</th>
				  <th>Father Name</th>
				  <th>Father Contact No.</th>
				  <th>Annual Income</th>
                  <th>Mother Name</th>
                  <th>Action</th>
                  <th>Enable / Disable</th>
                  
                  <th>Student Photo</th>
                  <th>Income Certificate</th>
                  <th>Aadhar Card</th>
                  <th>Caste Certificate</th>
                  <th>Bank Passbook</th>
                </tr>
						</thead>
						<tbody>
						<?php
						$query19="select * from student_admission_info_website where status='Active'";
						$run19=mysqli_query($conn73,$query19) or die(mysqli_error($conn73));
						$ser=0;
						while($row=mysqli_fetch_assoc($run19)){
						$s_no=$row['s_no'];
						$selection_roll_no=$row['selection_roll_no'];
						$selection_obtain_marks=$row['selection_obtain_marks'];
						$student_name=$row['student_name'];
						$student_admission_class=$row['student_admission_class'];
						$student_mobile_no=$row['student_mobile_no'];
						$student_category=$row['student_category'];
						$student_dob=$row['student_dob'];
						$student_gender=$row['student_gender'];
						$father_name=$row['father_name'];
						$father_mobile_no=$row['father_mobile_no'];
						$father_annual_income=$row['father_annual_income'];
						$mother_name=$row['mother_name'];
						$website_status=$row['website_status'];
						
                        $student_image=$row['student_image'];
                        $income_certificate_image=$row['income_certificate_image'];
                        $student_uid_image=$row['student_uid_image'];
                        $caste_certificate_image=$row['caste_certificate_image'];
                        $bank_passbook_image=$row['bank_passbook_image'];
						
						$ser++;
						?>
						<tr>
						    <td><?php echo $ser; ?></td>
						    <td><?php echo $selection_roll_no; ?></td>
						    <td><?php echo $selection_obtain_marks; ?></td>
						    <td><?php echo $student_name; ?></td>
						    <td><?php echo $student_admission_class; ?></td>
						    <td><?php echo $student_mobile_no; ?></td>
						    <td><?php echo $student_category; ?></td>
						    <td><?php echo $student_dob; ?></td>
						    <td><?php echo $student_gender; ?></td>
						    <td><?php echo $father_name; ?></td>
						    <td><?php echo $father_mobile_no; ?></td>
						    <td><?php echo $father_annual_income; ?></td>
						    <td><?php echo $mother_name; ?></td>
						    <td><button type="button"  class="btn btn-danger" onclick="return valid('<?php echo $s_no; ?>');" >Delete</button></td>
						    <?php if($website_status=='Enable'){ ?>
						    <td><button type="button"  class="btn btn-success" onclick="for_status('<?php echo $s_no; ?>','Disable');" >Make Disable</button></td>
						    <?php }else{ ?>
						    <td><button type="button"  class="btn btn-success" onclick="for_status('<?php echo $s_no; ?>','Enable');" >Make Enable</button></td>
						    <?php } ?>
						    
						    <td><?php if($student_image!=''){ ?><a href="<?php if($student_image!=''){ echo $_SESSION['amazon_file_path']."student_admission_info_website/".$student_image; } ?>" target="_blank"><button type="button" class="btn btn-success" >Print</button></a><?php } ?></td>
						    <td><?php if($income_certificate_image!=''){ ?><a href="<?php if($income_certificate_image!=''){ echo $_SESSION['amazon_file_path']."student_admission_info_website/".$income_certificate_image; } ?>" target="_blank"><button type="button" class="btn btn-success" >Print</button></a><?php } ?></td>
						    <td><?php if($student_uid_image!=''){ ?><a href="<?php if($student_uid_image!=''){ echo $_SESSION['amazon_file_path']."student_admission_info_website/".$student_uid_image; } ?>" target="_blank"><button type="button" class="btn btn-success" >Print</button></a><?php } ?></td>
						    <td><?php if($caste_certificate_image!=''){ ?><a href="<?php if($caste_certificate_image!=''){ echo $_SESSION['amazon_file_path']."student_admission_info_website/".$caste_certificate_image; } ?>" target="_blank"><button type="button" class="btn btn-success" >Print</button></a><?php } ?></td>
						    <td><?php if($bank_passbook_image!=''){ ?><a href="<?php if($bank_passbook_image!=''){ echo $_SESSION['amazon_file_path']."student_admission_info_website/".$bank_passbook_image; } ?>" target="_blank"><button type="button" class="btn btn-success" >Print</button></a><?php } ?></td>
						</tr>
						<?php } ?>
						</tbody>
				 </table>
			</div>
			 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
<script>
$(function () {
$('#example1').DataTable()
})
</script>