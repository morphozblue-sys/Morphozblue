<?php include("../attachment/session.php"); ?>
    <section class="content-header">
      <h1>
        <?php echo $language['Student Management']; ?>
        <small><?php echo $language['Control Panel']; ?></small>
      </h1>
      <ol class="breadcrumb">
	 <li><a href="javascript:get_content('index_content')"><i class="fa fa-dashboard"></i> Home</a></li>
	  <li><a href="javascript:get_content('student/students')"><i class="fa fa-graduation-cap"></i> <?php echo $language['Student']; ?></a></li>
	  <li class="active"><?php echo $language['Student Registration List']; ?></li>
      </ol>
    </section>
	
<script>
function valid(student_roll_no,student_date_of_admission,student_registration_fee){   
var myval=confirm("Are you sure want to delete this record !!!!");
if(myval==true){
registration_delete(student_roll_no,student_date_of_admission,student_registration_fee);      
 }            
else  {      
return false;
 }       
  } 
  function registration_delete(student_roll_no,student_date_of_admission,student_registration_fee){

$("#get_content").html(loader_div);
$.ajax({
type: "POST",
url: access_link+"student/student_registration_delete.php?id="+student_roll_no+"&date="+student_date_of_admission+"&amount="+student_registration_fee+"",
cache: false,
success: function(detail){
	  var res=detail.split("|?|");
			   if(res[1]=='success'){
				   get_content('student/student_registration_list');
			   }else{
              //  alert(detail); 
			   }
}
});
}
</script>

	<!---******************************************************************************************************-->
 <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
    <div class="box box-primary my_border_top">
            <div class="box-header with-border ">
            <h3 class="box-title"><?php echo $language['Registration List']; ?></h3>
            </div>
 <div class="box-body ">
     	 <div class="col-md-3">	
					<div class="form-group" >
					    <label><?php echo $language['Class']; ?></label>
							<select name="student_class" onchange="for_list(this.value);" class="form-control" required>
						       <option value="All"><?php echo $language['All']; ?></option>
						       <?php 
  	                           $class37=$_SESSION['class_name37'];
							   $class371=explode('|?|',$class37);
							   $total_class=$_SESSION['class_total37'];
				               for($q=0;$q<$total_class;$q++){
                               $class_name=$class371[$q]; ?>
						       <option value="<?php echo $class_name; ?>"><?php echo $class_name; ?></option>
					     <?php } ?>
					    </select>
					</div>
				</div>
	<div class="col-md-12">
                <!-- /.box -->

                <div <div class="box <?php echo $box_head_color; ?>" >>
                <div class="box-header with-border">
                </div>
			
		<div class="box-body table-responsive" id="search_list">
				  <table id="example1" class="table table-bordered table-striped">
						<thead >
							             <tr>
				  <th>S.No</th>
				  <th><?php echo $language['Student Name']; ?></th>
				  <th><?php echo $language['Father Name']; ?></th>
				  <th><?php echo $language['Class']; ?></th>
				  <th>Father Contact No.</th>
				  <th><?php echo $language['Registration Date']; ?></th>
                  <!--<th>Remark</th>-->
                  <th>Reg. No.</th>
                  <th>Update By</th>
                  <th>Date</th>
                 <th><?php echo $language['Make Admission']; ?></th>
                 <th><?php echo $language ['Print']; ?></th>
                 <th><?php echo 'Print Fee Reciept'; ?></th>
				  <th><?php echo $language['Delete']; ?></th>
                </tr>
						</thead>
				 </table>
			</div>
			 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>

    <script>
$(function(){
 for_list('All');
})
   function for_list(student_class){
    var dataTable=$('#example1').DataTable({
                destroy: true,
                "processing": true,
                "serverSide":true,
                "ajax":{
                    url:access_link+"student/student_registration_list_fatch.php?student_class="+student_class,
                    type:"post"
                }
            });
    }
</script>