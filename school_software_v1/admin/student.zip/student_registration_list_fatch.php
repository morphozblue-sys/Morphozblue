<?php
error_reporting(0);
include("../attachment/session.php");
$request=$_REQUEST;
	$student_class=$_GET['student_class'];


	if($student_class=='All'){
	$condition1="";
	}else{
	$condition1=" and student_class='$student_class'";
	}
	
$sql1 ="select s_no from student_admission_info where registration_final='no' and student_status='Deactive' and session_value='$session1'$filter37 $condition1 ORDER BY s_no DESC";
$query=mysqli_query($conn73,$sql1);
$totalData=mysqli_num_rows($query);

$totalFilter=$totalData;

//Search
 $sql ="select s_no,student_name,student_father_name,student_class,student_roll_no,student_father_contact_number,student_date_of_admission,student_remark_1,student_registration_number,student_registration_fee,update_change,last_updated_date from student_admission_info  where registration_final='no' and student_status='Deactive' and session_value='$session1'$filter37 $condition1";
if(!empty($request['search']['value'])){
    $sql.=" AND (student_name Like '%".$request['search']['value']."%' ";
    $sql.=" OR student_father_name Like '%".$request['search']['value']."%' ";
    $sql.=" OR student_class Like '%".$request['search']['value']."%' ";
    $sql.=" OR student_registration_number Like '%".$request['search']['value']."%' ";
    $sql.=" OR student_father_contact_number Like '%".$request['search']['value']."%' ";
    $sql.=" OR student_date_of_admission Like' %".$request['search']['value']."%' ";
    $sql.=" OR student_remark_1 Like' %".$request['search']['value']."%' ";
    $sql.=" OR update_change Like '%".$request['search']['value']."%' )";
}
$query=mysqli_query($conn73,$sql);
$totalData=mysqli_num_rows($query);
$sql.=" ORDER BY s_no DESC  LIMIT ".
    $request['start']."  ,".$request['length'];
$query=mysqli_query($conn73,$sql);
$data=array();
$serial_no=0; 
$que12="select registration_form_pdf,reg_fee_reciept from school_info_pdf_info";
$run12=mysqli_query($conn73,$que12);
while($row12=mysqli_fetch_assoc($run12)){
	$registration_form_pdf = $row12['registration_form_pdf'];
	$reg_fee_reciept = $row12['reg_fee_reciept'];
	
}	
while($row=mysqli_fetch_assoc($query)){
     $subdata=array();
				$s_no=$row['s_no'];
				$student_name=$row['student_name'];
				$student_father_name=$row['student_father_name'];
				$student_class=$row['student_class'];
				$student_roll_no=$row['student_roll_no'];
				$student_registration_number=$row['student_registration_number'];
				$student_father_contact_no=$row['student_father_contact_number'];
				$student_date_of_admission=$row['student_date_of_admission'];
		     	$student_remark_1=$row['student_remark_1'];
		     	$student_registration_fee=$row['student_registration_fee'];
		     	
                $update_change=$row['update_change'];
                if($row['last_updated_date']!='0000-00-00'){
                $last_updated_date=date('d-m-Y',strtotime($row['last_updated_date']));
                }else{
                $last_updated_date=$row['last_updated_date'];
                }
		     	
				$serial_no++;
	
$pdf_link=$pdf_path."registration_form/".$registration_form_pdf."?id=".$student_roll_no;
$pdf_link1=$pdf_path."reg_fee_reciept/".$reg_fee_reciept."?id=".$student_roll_no;
    $subdata[]=$serial_no;  
    $subdata[]=$student_name; 
    $subdata[]=$student_father_name; 
    $subdata[]=$student_class; 
    $subdata[]=$student_father_contact_no; 
    $subdata[]=$student_date_of_admission; 
    $subdata[]=$student_registration_number; 
    
    // $subdata[]=$student_remark_1; 
    $subdata[]=$update_change;    
    $subdata[]=$last_updated_date; 
    
    $subdata[]="<button type='button' onclick=post_content('student/student_admission','student_roll_no=$student_roll_no') class='btn btn-success' >".$language['Make Admission']."</button>";    
    $subdata[]="<a href='$pdf_link' target='_blank'><button type='button' class='btn btn-success'>".$language['Print']."</button></a></td>";    
    $subdata[]="<a href='$pdf_link1' target='_blank'><button type='button' class='btn btn-success'>Print reciept</button></a></td>";    
    $subdata[]="<button type='button' class='btn btn-success' onclick=valid('$student_roll_no','$student_date_of_admission','$student_registration_fee') >".$language['Delete']."</button>";    
    

   
    $data[]=$subdata;
	
}

$json_data=array(
    "draw"              =>  intval($request['draw']),
    "recordsTotal"      =>  intval($totalData),
    "recordsFiltered"   =>  intval($totalFilter),
    "data"              =>  $data
);

echo json_encode($json_data);

?>